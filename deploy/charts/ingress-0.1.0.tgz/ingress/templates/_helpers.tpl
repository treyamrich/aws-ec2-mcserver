{{/*
Return the full name of the ingress resource
*/}}
{{- define "ingress.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end }}
