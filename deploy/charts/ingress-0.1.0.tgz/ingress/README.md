Ingress Component — Values

This chart template creates Ingress resources for one or more services and supports optional TLS via cert-manager.

Values (defaults shown where applicable):

- `ingressClassName` (string)
  - Ingress class name. This value is required by the template.

- `tls.enabled` (bool)
  - Whether to emit `tls:` blocks and request certs. Default: `false`.
- `tls.clusterIssuer` (string)
  - cert-manager ClusterIssuer to use. Default: `selfsigned`.
- `tls.secretNamePrefix` (string)
  - Prefix used when naming TLS secrets per service. Example: `tls-`.

- `domains` (map)
  - Map of host suffixes for different domain types, e.g.:
    ```yaml
    domains:
      lan: ".lan.local"
      tailscale: ".ts.lan.local"
    ```
  - The template combines the service `subdomain` (or `name`) with each domain suffix to build hostnames.
- `services` (list of objects)
  - Each object defines a service to expose. Fields:
    - `name` (string) — backend `Service` name (required).
    - `subdomain` (string) — hostname prefix; if omitted `name` is used.
    - `path` (string) — ingress path; default: `/`.
    - `port` (int) — backend port number; default: `443`.

ingressClassName: traefik
Example values fragment:

```yaml
services:
  - name: argocd-server
    subdomain: argocd
    path: /
    port: 80

domains:
  lan: ".lan.local"
  tailscale: ".tailnet.ts.net"

tls:
  enabled: true
  clusterIssuer: selfsigned
  secretNamePrefix: tls-

ingressClassName: traefik
```

Notes
- The template expects top-level `services` and `domains` (not nested under `ingress`).
- When `tls.enabled` is true the chart will create `tls.hosts` and set `secretName` per service.
- The generated hostnames are `{{ subdomain|default name }}{{ domainSuffix }}` for each domain suffix provided.

If you prefer the alternate shape (lifting `services`/`domains` to top-level values), let me know and I can add backward-compatible handling or update the chart README accordingly.