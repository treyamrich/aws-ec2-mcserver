{{/*
Return the full name of the app-template resource
*/}}
{{- define "app-template.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Render Vault Agent annotations for a given vault config.
Usage: {{ include "app-template.vault-annotations" $vaultConfig }}
*/}}
{{- define "app-template.vault-annotations" -}}
vault.hashicorp.com/agent-inject: "true"
vault.hashicorp.com/agent-extra-secret: "homelab-ca-bundle"
vault.hashicorp.com/ca-cert: "/vault/custom/ca.crt"
vault.hashicorp.com/role: {{ .role | quote }}
{{- range .secrets }}
vault.hashicorp.com/agent-inject-secret-{{ .name }}: {{ .path | quote }}
vault.hashicorp.com/agent-inject-template-{{ .name }}: |
  {{`{{- with secret "`}}{{ .path }}{{`" -}}`}}
  {{`{{ index .Data.data "`}}{{ .key }}{{`" }}`}}
  {{`{{- end -}}`}}
{{- end }}
{{- end }}
